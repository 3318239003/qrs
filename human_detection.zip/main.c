//�༶�˵�����

#include <stdio.h>
#include "mpu6050.h"
#include "ls1b.h"
#include "mips.h"
#include "lkdGui.h"
#include "user_rtc_drv.h"
#include "i2c/ads1015.h"
#include "ls1x_i2c_bus.h"
#include "user_gauge_drv.h"
#include "DS18B20.h"

extern  lkdFont defaultFont;
//-------------------------------------------------------------------------------------------------
// BSP
//-------------------------------------------------------------------------------------------------

#include "bsp.h"
#include "ls1x_fb.h"
char LCD_display_mode[] = LCD_800x480;

static unsigned char key_value=0;
char tt=0;

int main(void)
{
    printk("\r\nmain() function.\r\n");

    ls1x_drv_init();            		/* Initialize device drivers */

    //install_3th_libraries();      		/* Install 3th libraies */


    KEY_Init();//������ʼ��
    MPU_IIC_Init();
    ls1x_ads1015_ioctl(busI2C0,IOCTL_ADS1015_DISP_CONFIG_REG,NULL);

    hwd_ds18b20_init();
    tt=MPU6050_Init();
    printk("%d/n",tt);
    printk("%d/n",tt);
    printk("%d/n",tt);
    printk("%d/n",tt);
    user_rtc_init();

    defaultFontInit();/* �ֿ��ʼ�� */
    GuiUpdateDisplayAll();/* ������Ļ-���� */

    userAppInit();

    for (;;)
    {
        userAppMain();

        //ѭ�����ô��ڴ���
        GuiWinDisplay();
        MenukeyResult();

    }

}

/*
 * @@ End
 */
