/*
 * user_rtc_drv.c
 *
 * created: 2022/7/13
 *  author: 
 */

#include "bsp.h"
#include "ls1x_fb.h"
#include "user_rtc_drv.h"


struct tm now =
{
    .tm_sec = 00,
    .tm_min = 47,
    .tm_hour = 9,
    .tm_mday = 20,
    .tm_mon = 7,
    .tm_year = 2022,
};

void user_rtc_init(void)
{
 //��ʼ��RTC������
    ls1x_rtc_init(NULL, NULL);
    
    ls1x_rtc_set_datetime(&now);

}

   

