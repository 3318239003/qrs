#ifndef __DS18B20_H__
#define __DS18B20_H__
#include "ls1b_gpio.h"

#define int16   short
#define uint8 unsigned char
#define uint16 unsigned short int
#define HWD_18B20_PIN_DATA    gpio_read(53)

#define HWD_18B20_RESET   gpio_write(53,0)
#define HWD_18B20_SET       gpio_write(53,1)

#define HWD_18B20_INPUT     gpio_enable( 53, DIR_IN )
#define HWD_18B20_OUTPUT    gpio_enable( 53, DIR_OUT )

int16 hwd_ds18b20_get_temp(void);
void hwd_18b20_test(void);
uint8 hwd_ds18b20_init(void);
#endif 


