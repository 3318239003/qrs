/*
 * user_app_ui.c
 *
 * created: 2022/7/13
 *  author:
 */
/**
  * @file   menutest.h
  * @author  guoweilkd
  * @version V0.0.0
  * @date    2018/06/30
  * @brief  �˵�ʹ��Demo
  */
#include "user_app_ui.h"
#include "keyDriverPort.h"
#include "lkdGui.h"
#include "user_rtc_drv.h"
#include "ls1x_rtc.h"
#include "ls1b_gpio.h"
#include "mpu6050.h"
#include "ls1x_fb.h"
#include "user_gauge_drv.h"

#include "ls1x_i2c_bus.h"
#include "i2c/ads1015.h"
/* �˵����� */
enum MenuKeyIs keyStatus;
/* �˵���� */
lkdMenu HmiMenu;
/* �˵�ջ */
#define MENUSTACK_NUM 8
MenuStack userMenuStack[MENUSTACK_NUM];

/* �������� */
static void HomeFun(void *param);
static void MenuFun(void *param);
static void Win0Fun(void *param);
static void Win1Fun(void *param);
static void Win2Fun(void *param);
static void Win3Fun(void *param);
static void Win4_1Fun(void *param);
static void Win4_2Fun(void *param);
static void Win4_3Fun(void *param);
static void Win5Fun(void *param);
static void Win6Fun(void *param);
static void Win7Fun(void *param);

/* ���ڶ��� */
lkdWin homeWin = {5,5,470,790,"�ն˵�Ԫ",HomeFun,NULL};/* ���洰�� */
lkdWin menuWin = {5,5,470,790,"�ն˵�Ԫ",MenuFun,NULL};/* �˵����� */
lkdWin win0 = {5,5,470,790,"���紫����",Win0Fun,NULL};
lkdWin win1 = {5,5,470,790,"��̬��⴫����",Win1Fun,NULL};
lkdWin win2 = {5,5,470,790,"���ʴ�����",Win2Fun,NULL};
lkdWin win3 = {5,5,470,790,"����¶ȴ�����",Win3Fun,NULL};
//lkdWin win4 = {5,5,470,790,"",Win4_1Fun,NULL};
lkdWin win5 = {5,5,470,790,"Ƕ��ʽ UI ��ƿ���",Win5Fun,NULL};

/* �˵��ڵ㶨�� */


lkdMenuNode Node6 = {6,"Ƕ��ʽ UI",			NULL,	NULL,	&win5};
//lkdMenuNode Node5 = {5,"�����״�ϵͳ",		&Node6,	NULL,	&win4};
lkdMenuNode Node4 = {4,"����¶�",		&Node6,	NULL,	&win3};
lkdMenuNode Node3 = {3,"���ʴ�����",		&Node4,	NULL,	&win2};
lkdMenuNode Node2 = {2,"��̬��⴫����",		&Node3,	NULL,   &win1};
lkdMenuNode Node1 = {1,"���紫����",		&Node2,	NULL,	&win0};
lkdMenuNode Node0 = {0,"root",		NULL,	&Node1,	NULL};


/**
  *@brief  �˵����
  *@param  step ���� pNode �˵��ڵ�
  *@retval None
  */
static void MenuItemDealWith(lkdMenuNode *pNode)
{
    if(pNode->pSon != NULL) //չ��ѡ�нڵ�Ĳ˵�
    {
        GuiMenuCurrentNodeSonUnfold(&HmiMenu);
    }
    else if(pNode->user != NULL) //�򿪲˵���Ӧ�Ĵ���
    {
        GuiWinAdd(pNode->user);
    }
}

/**
  *@brief  �˵����ƺ���
  *@param  None
  *@retval None
  */
void MenuControlFun(void)
{
    switch(keyStatus)
    {
        case MKEY_UP:
            GuiMenuItemUpMove(&HmiMenu);
            break;
        case MKEY_DOWN:
            GuiMenuItemDownMove(&HmiMenu);
            break;
        case MKEY_LEFT:
        case MKEY_CANCEL:
            GuiMenuCurrentNodeHide(&HmiMenu);
            if(HmiMenu.count == 0) //��⵽�˵��˳��ź�
            {
                GuiWinDeleteTop();
            }
            break;
        case MKEY_RIGHT:
        case MKEY_OK:
            MenuItemDealWith(GuiMenuGetCurrentpNode(&HmiMenu));
            break;
    }
}

/**
  *@brief  �˵���ʼ��
  *@param  None
  *@retval None
  */
void UserMenuInit(void)
{
    HmiMenu.x = 5;
    HmiMenu.y = 55;
    HmiMenu.wide = 440;
    HmiMenu.hight = 760;
    HmiMenu.Itemshigh = 40;
    HmiMenu.ItemsWide = 200;
    HmiMenu.stack = userMenuStack;
    HmiMenu.stackNum = 8;
    HmiMenu.Root = &Node0;/* �˵�������˵��ڵ�󶨵�һ�� */
    HmiMenu.MenuDealWithFun = MenuControlFun;/* �˵����ƻص����� */
    GuiMenuInit(&HmiMenu);
}

/**
  *@brief  ���洰��ʵ��
  *@param  None
  *@retval None
  */
static void HomeFun(void *param)
{
    //�û�Ӧ�ô���:��ͼ��
    static uint8_t step;
    lkdColour forecolor = GuiGetForecolor();

    //if(step == 0)
    //{
        //GuiFillRect(homeWin.x + 10,homeWin.y + 10,homeWin.x + 40,homeWin.y + 40,CBLACK);
        //GuiRowText(32, 80+100,400, FONT_LEFT,"����1������Ӳ����������");
        //GuiRowText(32, 120+100,400, FONT_LEFT,"����2������ʱϵͳ���");
        //GuiRowText(32, 160+100,400, FONT_LEFT,"����3��LCD��ʾӦ�ÿ���");
        //GuiRowText(32, 200+100,400, FONT_LEFT,"����4����������Ӧ�ÿ���");
        //GuiRowText(32, 240+100,400, FONT_LEFT,"����5�������״�ϵͳ���");
        //GuiRowText(32, 280+100,400, FONT_LEFT,"����6��Ƕ��ʽ UI ��ƿ���");
        //step = 1;
    //}
    GuiWinAdd(&menuWin);
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
            break;
        case MKEY_DOWN:
            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            step = 0;
            break;
        case MKEY_OK:
            step = 0;
            GuiWinAdd(&menuWin);
            break;
    }
}

/**
  *@brief  �˵�����ʵ��
  *@param  None
  *@retval None
  */
static void MenuFun(void *param)
{
    if(HmiMenu.count == 0)
    {
        GuiMenuCurrentNodeSonUnfold(&HmiMenu);
    }
    HmiMenu.MenuDealWithFun();
}

/**
  *@brief  ����0ʵ�庯��
  *@param  None
  *@retval None
  */

  char Win0_falg=1;
unsigned short win0Fun_ADC=0;
unsigned short  Win0_x=0,Win0_y=0,Win0_x_=0,Win0_y_=0;

static void Win0Fun(void *param)
{
    win0Fun_ADC = get_ads1015_adc(busI2C0, ADS1015_REG_CONFIG_MUX_SINGLE_0);
     printf("%d\n",win0Fun_ADC);
     Win0_y=win0Fun_ADC/10;
    fb_drawline(Win0_x_+50, 440-Win0_y_, Win0_x+50,440-Win0_y, cidxYELLOW);
    fb_textout(360,10,"���紫����");
    Win0_x_=Win0_x;
    Win0_y_=Win0_y;
    Win0_x++;
    if(Win0_x>=790)
    {
        Win0_x=0;
        Win0_falg=1;
    }
    
    
     if(Win0_falg)
    {
        Win0_falg=0;
         fb_cons_clear();
        fb_drawline(50, 50, 50,470, cidxRED);
        fb_drawline(51, 51, 51,471, cidxRED);
        fb_drawline(52, 52, 52,472, cidxRED);
        fb_drawline(50, 50, 790,50, cidxRED);
        fb_drawline(51, 51, 791,51, cidxRED);
        fb_drawline(52, 52, 792,52 , cidxRED);
        fb_textout(22,40,"1000");
        fb_textout(22,80,"900");
        fb_textout(22,120,"800");
        fb_textout(22,160,"700");
        fb_textout(22,200,"600");
        fb_textout(22,240,"500");
        fb_textout(22,280,"400");
        fb_textout(22,320,"300");

        fb_textout(22,360,"300");
        fb_textout(22,400,"100");
        fb_textout(16,440,"000");


        fb_drawline(50, 80, 790,80, cidxGREEN);
        fb_drawline(50, 120, 790,120, cidxGREEN);
        fb_drawline(50, 160, 790,160, cidxGREEN);
        fb_drawline(50, 200, 790,200, cidxGREEN);

        fb_drawline(50, 240, 790,240, cidxGREEN);
        fb_drawline(50, 280, 790,280, cidxGREEN);
        fb_drawline(50, 320, 790,320, cidxGREEN);
        fb_drawline(50, 360, 790,360, cidxGREEN);

        fb_drawline(50, 400, 790,400, cidxGREEN);
        fb_drawline(50, 440, 790,440, cidxGREEN);
    }
    
    
    
    
    
    

    //�û�Ӧ�ô���:��ͼ��
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP://������



            break;
        case MKEY_DOWN:

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);

            break;
        case MKEY_OK:

            break;
    }
}


struct tm tmp=
{
    .tm_sec = 0,
    .tm_min = 0,
    .tm_hour = 0,
    .tm_mday = 0,
    .tm_mon = 0,
    .tm_year = 0,
};
/**
  *@brief  ����1ʵ�庯��
  *@param  None
  *@retval None
  */
uint8_t t;
int16_t angle_x=0,angle_y=0,angle_z=0;
int16_t aacx=0,aacy=0,aacz=0;		//���ٶȴ�����ԭʼ����
static void Win1Fun(void *param)
{
    static str[50]= {0};
    

    //MPU_Get_Accelerometer(&aacx,&aacy,&aacz);	//�õ����ٶȴ���������
   
	angle_x = MPU_Get_Accelerometer(&aacx,&aacy,&aacz);
    MPU_Get_Gyroscope(&angle_x,&angle_y,&angle_z);

    printk("x %d   y %d    z %d\n",aacx ,aacy,aacz);
    printk("ERROR %d \n",angle_x );
    //printk("z %d \n",aacz );
    GuiRowText(32, 130,400, FONT_LEFT,"�������ٶ�");
    sprintf(str,"    X��:%d    ",aacx);GuiRowText(32, 80+100,400, FONT_LEFT,str);
    sprintf(str,"    Y��:%d    ",aacy);GuiRowText(32, 120+100,400, FONT_LEFT,str);
    sprintf(str,"    Z��:%d    ",aacz);GuiRowText(32, 160+100,400, FONT_LEFT,str);
    GuiRowText(32, 330,400, FONT_LEFT,"�������ٶ�");
    sprintf(str,"    X��:%d    ",angle_x);GuiRowText(32, 80+300,400, FONT_LEFT,str);
    sprintf(str,"    Y��:%d    ",angle_y);GuiRowText(32, 120+300,400, FONT_LEFT,str);
    sprintf(str,"    Z��:%d    ",angle_z);GuiRowText(32, 160+300,400, FONT_LEFT,str);
    
    delay_ms(500);
        

   

    //�û�Ӧ�ô���:��ͼ��
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP://����ʱ��

            break;
        case MKEY_DOWN:

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            Win0_falg=1;
            Win0_x=0;
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:

            break;
    }

}
/**
  *@brief  ����2ʵ�庯��
  *@param  None
  *@retval None
  */
  char Win2_falg=1;
unsigned short win2Fun_ADC=0;
unsigned short  Win2_x=0,Win2_y=0,Win2_x_=0,Win2_y_=0;
static void Win2Fun(void *param)
{
     win2Fun_ADC = get_ads1015_adc(busI2C0, ADS1015_REG_CONFIG_MUX_SINGLE_2);
     printf("%d\n",win2Fun_ADC);
     Win2_y=win2Fun_ADC/10;
    fb_drawline(Win2_x_+50, 440-Win2_y_, Win2_x+50,440-Win2_y, cidxYELLOW);
    
    Win2_x_=Win2_x;
    Win2_y_=Win2_y;
    Win2_x++;
    if(Win2_x>=790)
    {
        Win2_x=0;
        Win2_falg=1;
    }
    if(Win2_falg)
    {
        Win2_falg=0;
         fb_cons_clear();
        fb_drawline(50, 50, 50,470, cidxRED);
        fb_drawline(51, 51, 51,471, cidxRED);
        fb_drawline(52, 52, 52,472, cidxRED);
        fb_drawline(50, 50, 790,50, cidxRED);
        fb_drawline(51, 51, 791,51, cidxRED);
        fb_drawline(52, 52, 792,52 , cidxRED);
        fb_textout(360,10,"���ʴ�����");
        //fb_textout(40,40,"0");
        //fb_textout(22,80,"100");
        //fb_textout(22,120,"200");
        //fb_textout(22,160,"300");
        //fb_textout(22,200,"400");
        //fb_textout(22,240,"500");
        //fb_textout(22,280,"600");
        //fb_textout(22,320,"700");

        //fb_textout(22,360,"800");
        //fb_textout(22,400,"900");
        //fb_textout(16,440,"1000");


        fb_textout(22,40,"1000");
        fb_textout(22,80,"900");
        fb_textout(22,120,"800");
        fb_textout(22,160,"700");
        fb_textout(22,200,"600");
        fb_textout(22,240,"500");
        fb_textout(22,280,"400");
        fb_textout(22,320,"300");

        fb_textout(22,360,"300");
        fb_textout(22,400,"100");
        fb_textout(16,440,"000");

        


        fb_drawline(50, 80, 790,80, cidxGREEN);
        fb_drawline(50, 120, 790,120, cidxGREEN);
        fb_drawline(50, 160, 790,160, cidxGREEN);
        fb_drawline(50, 200, 790,200, cidxGREEN);

        fb_drawline(50, 240, 790,240, cidxGREEN);
        fb_drawline(50, 280, 790,280, cidxGREEN);
        fb_drawline(50, 320, 790,320, cidxGREEN);
        fb_drawline(50, 360, 790,360, cidxGREEN);

        fb_drawline(50, 400, 790,400, cidxGREEN);
        fb_drawline(50, 440, 790,440, cidxGREEN);
    }
   

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:


            break;
        case MKEY_DOWN://��ť����

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            Win2_falg=1;
            Win2_x=0;
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);

            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����3ʵ�庯��
  *@param  None
  *@retval None
  */
float Temp_DS=0,Temp_DS_=0;
uint16_t Temp_time=0,Temp_time_=0;
static void Win3Fun(void *param)
{
    static str[50]= {0};

    Temp_DS=(hwd_ds18b20_get_temp()/10)+((hwd_ds18b20_get_temp()%10)*0.1);
    printk("%.02f",Temp_DS);
    sprintf(str,"  �¶�:%.02f ",(float)Temp_DS);
    GuiRowText(0, 530,460, FONT_MID,str);
    fb_drawline(700, 5, 700,400, cidxRED);fb_textout(700,410,"50");
    fb_drawline(680, 5, 680,400, cidxRED);fb_textout(680,410,"40");
    fb_drawline(660, 5, 660,400, cidxRED);fb_textout(660,410,"30");
    fb_drawline(640, 5, 640,400, cidxRED);fb_textout(640,410,"20");
    fb_drawline(620, 5, 620,400, cidxRED);fb_textout(620,410,"10");
    fb_drawline(600, 5, 600,400 , cidxRED);fb_textout(600,410,"0");
    fb_drawline(600+Temp_DS_*2,Temp_time_+5,  600+Temp_DS*2,Temp_time+5, cidxBRTYELLOW);
    Temp_DS_=Temp_DS;
    Temp_time_=Temp_time;
    Temp_time++;
    if(Temp_time>=400)
    {
        Temp_time_=0;
        Temp_time=0;
        fb_cons_clear();
    }
             
    

    

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:

            break;
        case MKEY_DOWN://��ʾͼƬ


            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            Temp_time=0;
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����4_1ʵ�庯��
  *@param  None
  *@retval None
  */

static void Win4_1Fun(void *param)
{
   
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:

            break;
        case MKEY_DOWN:

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);

            break;
        case MKEY_OK:
            break;
    }
}

/**
  *@brief  ����5ʵ�庯��
  *@param  None
  *@retval None
  */
  unsigned int data,data1,count1,count;
static uint16_t motor_show_speed=0;
static uint16_t env_motor_show_speed=0;
static Win5_Task_Flag=0;
static uint16_t light_value=0;
int key = 0;
unsigned char t=0;
    char a = 0;
static void Win5Fun(void *param)
{
    char str[50]= {0};

	if(Win5_Task_Flag==0)
	{
    GuiRowText(0, 100,480, FONT_MID,"S1:��ʾ����ǿ��");
    GuiRowText(0, 130,480, FONT_MID,"S2:��ʾ����");
    Win5_Task_Flag=1;
	}



    light_value=BH1750_Test();
    if(a == 1)
    {
        sprintf(str," ��ǰ������ǿ�ȣ�%d lx ",light_value);
        GuiRowText(0, 264,460, FONT_MID,str);
    }
    if(a == 2)
    {
        fb_open();
        fb_cons_clear();
        delay_ms(200);
        fb_drawline(50, 50, 50,470, cidxRED);
        fb_drawline(51, 51, 51,471, cidxRED);
        fb_drawline(52, 52, 52,472, cidxRED);
        fb_drawline(50, 50, 790,50, cidxRED);
        fb_drawline(51, 51, 791,51, cidxRED);
        fb_drawline(52, 52, 792,52 , cidxRED);
        fb_drawpixel(100, 780, cidxRED);
        fb_textout(40,40,"0");
        fb_textout(22,80,"100");
        fb_textout(22,120,"200");
        fb_textout(22,160,"300");
        fb_textout(22,200,"400");
        fb_textout(22,240,"500");
        fb_textout(22,280,"600");
        fb_textout(22,320,"700");
        fb_textout(22,360,"800");
        fb_textout(22,400,"900");
        fb_textout(16,440,"1000");
        fb_drawline(50, 80, 790,80, cidxGREEN);
        fb_drawline(50, 120, 790,120, cidxGREEN);
        fb_drawline(50, 160, 790,160, cidxGREEN);
        fb_drawline(50, 200, 790,200, cidxGREEN);
        fb_drawline(50, 240, 790,240, cidxGREEN);
        fb_drawline(50, 280, 790,280, cidxGREEN);
        fb_drawline(50, 320, 790,320, cidxGREEN);
        fb_drawline(50, 360, 790,360, cidxGREEN);
        fb_drawline(50, 400, 790,400, cidxGREEN);
        fb_drawline(50, 440, 790,440, cidxGREEN);
        while(1)
        {
            data1 = BH1750_Test();
            data1 = data1 / 2.5;
            //   delay_ms(2000);
            fb_drawline(50+count1, data+50, 50+count,data1+50, cidxBRTYELLOW);
            data = data1;
            count1 = count;
            count =count+10;
            if(count >= 800)
            {
                fb_cons_clear();
                fb_drawline(50, 50, 50,470, cidxRED);
                fb_drawline(51, 51, 51,471, cidxRED);
                fb_drawline(52, 52, 52,472, cidxRED);
                fb_drawline(50, 50, 790,50, cidxRED);
                fb_drawline(51, 51, 791,51, cidxRED);
                fb_drawline(52, 52, 792,52 , cidxRED);
                fb_textout(40,40,"0");
                fb_textout(22,80,"100");

                fb_textout(22,120,"200");
                fb_textout(22,160,"300");
                fb_textout(22,200,"400");
                fb_textout(22,240,"500");
                fb_textout(22,280,"600");
                fb_textout(22,320,"700");

                fb_textout(22,360,"800");
                fb_textout(22,400,"900");
                fb_textout(16,440,"1000");


                fb_drawline(50, 80, 790,80, cidxGREEN);
                fb_drawline(50, 120, 790,120, cidxGREEN);
                fb_drawline(50, 160, 790,160, cidxGREEN);
                fb_drawline(50, 200, 790,200, cidxGREEN);

                fb_drawline(50, 240, 790,240, cidxGREEN);
                fb_drawline(50, 280, 790,280, cidxGREEN);
                fb_drawline(50, 320, 790,320, cidxGREEN);
                fb_drawline(50, 360, 790,360, cidxGREEN);

                fb_drawline(50, 400, 790,400, cidxGREEN);
                fb_drawline(50, 440, 790,440, cidxGREEN);

                count = 0;
                count1=0;
            }
            key = KEY_Scan();
            if(key == 4)
            {

                a=0;
                fb_cons_clear();
                     GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
                break;

            }


        }
    }

    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:
		 a = 1;
            break;
        case MKEY_DOWN://
         a = 2;
            break;
        case MKEY_LEFT:

            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}

#if 0
/**
  *@brief  ����4ʵ�庯��
  *@param  None
  *@retval None
  */
static void Win4Fun(void *param)
{
    /* ����״̬���� */
    switch(keyStatus)
    {
        case MKEY_UP:

            break;
        case MKEY_DOWN://��ʾͼƬ

            break;
        case MKEY_LEFT:
            break;
        case MKEY_RIGHT:
            break;
        case MKEY_CANCEL:
            GuiWinDeleteTop();
            GuiMenuRedrawMenu(&HmiMenu);
            break;
        case MKEY_OK:
            break;
    }
}

#endif
/**
  *@brief  �û��˵�������
  *@param  None
  *@retval None
  */
void userAppMain(void)
{
    keyStatus = GetMenuKeyState();
    SetMenuKeyIsNoKey();
}

/**
  *@brief  �û�Ӧ�ó�ʼ��
  *@param  None
  *@retval None
  */
void userAppInit(void)
{
    UserMenuInit();
    GuiSetForecolor(1);
    GuiSetbackcolor(0);
    GuiWinAdd(&homeWin);
}

/* END */
