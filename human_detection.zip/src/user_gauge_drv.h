/*
 * user_gauge_drv.h
 *
 * created: 2022/8/11
 *  author: 
 */

#ifndef _USER_GAUGE_DRV_H
#define _USER_GAUGE_DRV_H

#ifdef __cplusplus
extern "C" {
#endif
#include "stdint.h"

typedef struct
{
    int x;// X
    int y;//Y
	int r;//�뾶
	double angle;//�Ƕ�0~360
	int init_angle;//��ʼ�Ƕ�ƫ��
	double last_angle;//��ʼ�Ƕ�ƫ��

}gauge_dev;
void gauge_create(gauge_dev* gauge);
void OLED_DrawAngleLine_clear(unsigned int x,unsigned int y,double du,unsigned int len,unsigned int w,gauge_dev* gauge);
void OLED_DrawAngleLine(unsigned int x,unsigned int y,double du,unsigned int len,unsigned int w,gauge_dev* gauge);
void GUI_Draw_Circle_8(int xc, int yc, int x, int y, uint16_t c);
void GUI_Circle(int xc, int yc, uint16_t c,uint16_t r, int fill);
void gauge_creat(uint16_t x,uint16_t y,uint16_t r);
void gauge_test(gauge_dev* gauge);
void OLED_DrawAngleLine_Font_struct(gauge_dev* gauge,double du,char *str);
void set_gauge_value(gauge_dev* gauge);
#ifdef __cplusplus
}
#endif

#endif // _USER_GAUGE_DRV_H

