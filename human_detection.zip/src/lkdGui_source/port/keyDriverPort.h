/*
 * keyDriverPort.h
 *
 * created: 2022/7/13
 *  author: 
 */

#ifndef _KEYDRIVERPORT_H
#define _KEYDRIVERPORT_H


#include "ls1b.h"
#include "stdint.h"

#define KEY_NUM_ALL 4

/* ��Ӳ����� */
#define KEY_HARDWARE_UP   1


/* ����״̬ */
typedef enum{
	KEYUP,
	KEYDOWN,
	KEYERROR
}KeyStatus;

/* �������� */
struct KeyInfo{
	uint32_t filterCount[KEY_NUM_ALL];
	uint8_t  stepFlag[KEY_NUM_ALL];
	uint8_t  currentStatus[KEY_NUM_ALL];
};

#define MENUY_UP			1
#define MENUKEY_DOWN		2
#define MENUKEY_LEFT		5
#define MENUKEY_RIGHT		6
#define MENUKEY_OK			3
#define MENUKEY_CANCEL	    4

enum MenuKeyIs{
	MKEY_NO,
	MKEY_UP,
	MKEY_DOWN,
	MKEY_LEFT,
	MKEY_RIGHT,
	MKEY_OK,
	MKEY_CANCEL
};


void KeyDriverInit(void);

void SetMenuKeyIsNoKey(void);
enum MenuKeyIs GetMenuKeyState(void);

/* �����ⲿ���� */
extern uint32_t GetTimer1Tick(void);
extern uint32_t GetTimer1IntervalTick(uint32_t beginTick);


#endif // _KEYDRIVERPORT_H

