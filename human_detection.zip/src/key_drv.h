/*
 * test.h
 *
 * created: 2021/7/24
 *  author: 
 */

#ifndef _TEST_H
#define _TEST_H


#define KEY_1 56
#define KEY_2  57
#define KEY_3  40
#define KEY_4  41

void KEY_Init(void);
unsigned char KEY_Scan();
#endif // _TEST_H

